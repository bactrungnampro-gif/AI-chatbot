/** @type {import('next').NextConfig} */
const nextConfig = {
  // Cho phép body lớn khi gửi ảnh base64 (Giai đoạn 2 - multimodal)
  experimental: {
    serverActions: { bodySizeLimit: '10mb' },
  },
};

export default nextConfig;

# Agent RAG — Trợ Lý AI Tư Vấn (Next.js + Supabase)

Bộ khung dự án **Giai đoạn 0** theo đặc tả kỹ thuật (`docs/Dac-ta-ky-thuat-Agent-RAG.docx`).
Mục tiêu Giai đoạn 0: **khung chạy được + database sẵn sàng**. Các luồng RAG/chat/nạp là stub, sẽ làm ở Giai đoạn 1–2.

## Cấu trúc

```
src/
  app/
    layout.tsx
    page.tsx                 # trang trạng thái cấu hình
    api/health/route.ts      # kiểm tra env + kết nối DB
  lib/
    env.ts                   # đọc biến môi trường
    supabase.ts              # client server-side (service role)
    embeddings.ts            # tạo embedding (OpenAI text-embedding-3-small)
    retrieval.ts             # truy hồi top-K (Giai đoạn 2)
    prompt.ts                # ghép prompt ưu tiên/fallback (mục 9)
    llm/index.ts             # lớp trừu tượng LLM đa provider (Giai đoạn 2)
supabase/
  migrations/0001_init.sql   # schema: sources, chunks(vector), products, app_config...
```

## Cài đặt (làm 1 lần)

### 1. Cài dependencies
```bash
npm install
```

### 2. Tạo project Supabase + chạy migration
1. Tạo project tại https://supabase.com (gói Free).
2. Vào **SQL Editor** → dán toàn bộ nội dung `supabase/migrations/0001_init.sql` → **Run**.
3. Vào **Project Settings → API**, lấy: `Project URL`, `anon public key`, `service_role key`.

### 3. Tạo file `.env.local`
Sao chép `.env.example` thành `.env.local` rồi điền:
```bash
cp .env.example .env.local
```
Tối thiểu cho Giai đoạn 0:
```
NEXT_PUBLIC_SUPABASE_URL=...        # Project URL
NEXT_PUBLIC_SUPABASE_ANON_KEY=...   # anon public
SUPABASE_SERVICE_ROLE_KEY=...       # service_role (bí mật)
```
(Các khóa `OPENAI_API_KEY`, `GEMINI_API_KEY`, `FIRECRAWL_API_KEY` cần ở Giai đoạn 1–2.)

### 4. Chạy thử
```bash
npm run dev
```
Mở http://localhost:3000 — nếu thấy **✓ Kết nối Database** là Giai đoạn 0 xong.

## Deploy lên Vercel
1. Đẩy code lên GitHub (repo mới).
2. Vào https://vercel.com → Import repo → thêm các biến môi trường (giống `.env.local`).
3. Deploy. Kiểm tra `/api/health`.

## Bước tiếp theo (Giai đoạn 1)
- Lấy `FIRECRAWL_API_KEY` (https://firecrawl.dev) và `OPENAI_API_KEY` (cho embedding).
- Triển khai `src/lib/ingest/` (chunk + firecrawl) và `POST /api/ingest` để nạp 1 website đầu tiên vào DB.

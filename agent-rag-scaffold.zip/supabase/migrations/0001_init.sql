-- ============================================================
-- Agent RAG — Migration khởi tạo (Giai đoạn 0)
-- Chạy trong Supabase: SQL Editor -> dán toàn bộ -> Run
-- ============================================================

create extension if not exists vector;

-- Nguồn tri thức (1 dòng / website / sheet / drive / tài liệu)
create table if not exists knowledge_sources (
  id          uuid primary key default gen_random_uuid(),
  title       text not null,
  type        text not null,          -- website | google_drive | google_sheet | manual | product_catalog
  url         text,
  active      boolean default true,
  status      text default 'pending', -- pending | processing | done | error
  created_at  timestamptz default now()
);

-- Đoạn tri thức + embedding (1536 chiều cho OpenAI text-embedding-3-small)
create table if not exists knowledge_chunks (
  id          bigserial primary key,
  source_id   uuid references knowledge_sources(id) on delete cascade,
  content     text not null,
  title       text,
  url         text,
  product_id  uuid,
  chunk_index int,
  embedding   vector(1536),
  created_at  timestamptz default now()
);
create index if not exists knowledge_chunks_embedding_idx
  on knowledge_chunks using hnsw (embedding vector_cosine_ops);

-- Sản phẩm (cho tư vấn bán hàng)
create table if not exists products (
  id             uuid primary key default gen_random_uuid(),
  name           text not null,
  category       text,
  price          bigint,
  original_price bigint,
  description    text,
  key_features   text[],
  image_url      text,
  in_stock       boolean default true,
  source_url     text
);

-- Ảnh sản phẩm (Giai đoạn 5 — image search; số chiều tùy model, tạm 1024)
create table if not exists product_images (
  id          bigserial primary key,
  product_id  uuid references products(id) on delete cascade,
  image_url   text,
  embedding   vector(1024)
);

-- Cấu hình agent (persona, model, tone, ngưỡng grounded, greeting...)
create table if not exists app_config (
  id          text primary key default 'default',
  data        jsonb not null default '{}'::jsonb,
  updated_at  timestamptz default now()
);

-- Hàm truy hồi top-K theo cosine (dùng ở Giai đoạn 2)
create or replace function match_chunks(query_embedding vector(1536), match_count int default 6)
returns table (content text, title text, url text, product_id uuid, similarity float)
language sql stable as $$
  select c.content, c.title, c.url, c.product_id,
         1 - (c.embedding <=> query_embedding) as similarity
  from knowledge_chunks c
  join knowledge_sources s on s.id = c.source_id
  where s.active = true
  order by c.embedding <=> query_embedding
  limit match_count;
$$;

-- Cấu hình mặc định ban đầu
insert into app_config (id, data)
values ('default', '{
  "businessName": "Doanh Nghiệp Của Bạn",
  "agentName": "Trợ Lý AI",
  "tone": "friendly",
  "model": "gemini-2.5-flash",
  "visionModel": "gemini-2.5-flash",
  "groundedThreshold": 0.75,
  "greeting": "Xin chào! Em có thể giúp gì cho anh/chị hôm nay ạ?"
}'::jsonb)
on conflict (id) do nothing;

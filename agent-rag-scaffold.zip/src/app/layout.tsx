import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Agent RAG — Trợ Lý AI Tư Vấn',
  description: 'Chatbot tư vấn & hướng dẫn dựa trên RAG (dữ liệu nạp) + fallback AI.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi">
      <body style={{ fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif', margin: 0 }}>
        {children}
      </body>
    </html>
  );
}

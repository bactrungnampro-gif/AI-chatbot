// Trang trạng thái đơn giản cho Giai đoạn 0 — kiểm tra khung dự án + kết nối DB.
async function getHealth() {
  try {
    const base = process.env.NEXT_PUBLIC_BASE_URL || '';
    const res = await fetch(`${base}/api/health`, { cache: 'no-store' });
    return await res.json();
  } catch {
    return null;
  }
}

export default async function Home() {
  const health = await getHealth();
  const row = (label: string, ok: boolean) => (
    <li style={{ margin: '4px 0' }}>
      <span style={{ color: ok ? '#059669' : '#dc2626' }}>{ok ? '✓' : '✗'}</span> {label}
    </li>
  );

  return (
    <main style={{ maxWidth: 720, margin: '48px auto', padding: '0 20px', color: '#1e293b' }}>
      <h1 style={{ color: '#2563eb' }}>Agent RAG — Giai đoạn 0</h1>
      <p>Khung dự án đã chạy. Kiểm tra cấu hình bên dưới, rồi chuyển sang Giai đoạn 1 (nạp dữ liệu).</p>

      <h3>Trạng thái cấu hình</h3>
      {health ? (
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {row('Supabase URL', health.env?.supabaseUrl)}
          {row('Supabase Service Key', health.env?.supabaseServiceKey)}
          {row('Kết nối Database', health.db?.ok)}
          {row('Gemini API Key', health.env?.gemini)}
          {row('OpenAI API Key (embedding)', health.env?.openai)}
          {row('Firecrawl API Key', health.env?.firecrawl)}
        </ul>
      ) : (
        <p style={{ color: '#dc2626' }}>Chưa gọi được /api/health. Kiểm tra server.</p>
      )}

      <p style={{ marginTop: 24, fontSize: 13, color: '#64748b' }}>
        Xem hướng dẫn cài đặt trong <code>README.md</code>. Các mục ✗ cần điền vào file <code>.env.local</code>.
      </p>
    </main>
  );
}

import { NextResponse } from 'next/server';
import { envStatus } from '@/lib/env';
import { getServiceClient } from '@/lib/supabase';

export async function GET() {
  const env = envStatus();
  let db: { ok: boolean; error?: string } = { ok: false };

  // Thử ping DB nếu đã cấu hình Supabase
  if (env.supabaseUrl && env.supabaseServiceKey) {
    try {
      const supabase = getServiceClient();
      const { error } = await supabase.from('app_config').select('id').limit(1);
      db = error ? { ok: false, error: error.message } : { ok: true };
    } catch (e: any) {
      db = { ok: false, error: e?.message || String(e) };
    }
  }

  return NextResponse.json({
    status: 'ok',
    phase: 'Giai đoạn 0 — khung dự án',
    env,
    db,
    timestamp: new Date().toISOString(),
  });
}

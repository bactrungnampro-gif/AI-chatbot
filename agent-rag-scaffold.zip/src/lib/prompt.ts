// Ghép system prompt theo cơ chế ưu tiên dữ liệu nạp -> fallback AI (mục 9 đặc tả).
import type { Hit } from './retrieval';

interface BuildArgs {
  businessName: string;
  agentName: string;
  tone: string;
  hits: Hit[];
  grounded: boolean;
}

export function buildSystemPrompt({ businessName, agentName, tone, hits, grounded }: BuildArgs): string {
  const context = grounded
    ? hits.map((h) => `[${h.title ?? 'Nguồn'}](${h.url ?? ''})\n${h.content}`).join('\n---\n')
    : '(không có dữ liệu liên quan trong kho tri thức)';

  return `Bạn là trợ lý của "${businessName}". Vai trò: ${agentName}. Giọng: ${tone}.

QUY TẮC TRẢ LỜI (theo thứ tự ưu tiên):
1) Nếu [NGỮ CẢNH] chứa thông tin liên quan: TRẢ LỜI DỰA TRÊN [NGỮ CẢNH]. Được dẫn link/hình từ metadata trong ngữ cảnh.
2) Nếu [NGỮ CẢNH] trống/không đủ: dùng kiến thức chung để trả lời hữu ích, ĐÚNG vai trò "${businessName}".
   TUYỆT ĐỐI không bịa link, giá, chính sách không có trong ngữ cảnh.
3) Không bao giờ bịa nguồn. Chỉ dùng link xuất hiện trong [NGỮ CẢNH].
4) Nếu là ý định mua hàng: ưu tiên gợi ý sản phẩm phù hợp kèm lý do; hỏi lại 1 câu nếu thiếu thông tin.

[NGỮ CẢNH]
${context}`;
}

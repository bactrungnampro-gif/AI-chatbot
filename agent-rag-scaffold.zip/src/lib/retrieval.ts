// Truy hồi top-K đoạn tri thức liên quan tới câu hỏi.
// TODO (Giai đoạn 2): nối vào /api/chat.
import { getServiceClient } from './supabase';
import { embedBatch } from './embeddings';

export interface Hit {
  content: string;
  title: string | null;
  url: string | null;
  product_id: string | null;
  similarity: number;
}

export async function retrieve(query: string, matchCount = 6): Promise<Hit[]> {
  const [qVec] = await embedBatch([query]);
  const supabase = getServiceClient();
  const { data, error } = await supabase.rpc('match_chunks', {
    query_embedding: qVec,
    match_count: matchCount,
  });
  if (error) throw new Error(`Truy hồi lỗi: ${error.message}`);
  return (data || []) as Hit[];
}

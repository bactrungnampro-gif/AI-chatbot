import { createClient } from '@supabase/supabase-js';
import { requireEnv } from './env';

// Client server-side dùng service role key (toàn quyền — CHỈ dùng trong API routes/server).
// KHÔNG import file này vào code chạy ở trình duyệt.
export function getServiceClient() {
  return createClient(
    requireEnv('NEXT_PUBLIC_SUPABASE_URL'),
    requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
    { auth: { persistSession: false } }
  );
}

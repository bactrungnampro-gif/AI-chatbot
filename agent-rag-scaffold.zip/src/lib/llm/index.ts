// Lớp trừu tượng gọi LLM đa nhà cung cấp (đổi provider không phải viết lại phần còn lại).
// TODO (Giai đoạn 2): triển khai gemini.ts / openai.ts / anthropic.ts / deepseek.ts + streaming + function calling.

export type Provider = 'google' | 'openai' | 'anthropic' | 'deepseek';

export interface Attachment {
  mimeType: string;
  dataUrl?: string;
  url?: string;
}

export interface GenerateArgs {
  system: string;
  message: string;
  history?: { role: 'user' | 'assistant'; content: string }[];
  attachments?: Attachment[];
  model: string;
  provider?: Provider;
  temperature?: number;
}

// Placeholder — sẽ triển khai ở Giai đoạn 2.
export async function generate(_args: GenerateArgs): Promise<string> {
  throw new Error('Chưa triển khai: lib/llm (Giai đoạn 2).');
}

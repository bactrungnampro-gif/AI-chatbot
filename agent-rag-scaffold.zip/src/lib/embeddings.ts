// Tạo embedding cho văn bản. Mặc định: OpenAI text-embedding-3-small (1536 chiều).
// TODO (Giai đoạn 1): triển khai gọi API thật + batch + throttle.
import { requireEnv } from './env';

const EMBED_MODEL = 'text-embedding-3-small';
const EMBED_DIM = 1536;

export async function embedBatch(texts: string[]): Promise<number[][]> {
  if (texts.length === 0) return [];
  const apiKey = requireEnv('OPENAI_API_KEY');
  const res = await fetch('https://api.openai.com/v1/embeddings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
    body: JSON.stringify({ model: EMBED_MODEL, input: texts }),
  });
  if (!res.ok) throw new Error(`Embedding lỗi HTTP ${res.status}: ${await res.text()}`);
  const data = await res.json();
  return data.data.map((d: any) => d.embedding as number[]);
}

export { EMBED_DIM, EMBED_MODEL };
